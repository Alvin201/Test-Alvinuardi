<?php

	include 'connect.php';

	function encrypt($data, $password){
	    $iv = substr(sha1(mt_rand()), 0, 16);
	    $password = sha1($password);

	    $salt = sha1(mt_rand());
	    $saltWithPassword = hash('sha256', $password.$salt);

	    $encrypted = openssl_encrypt(
	      "$data", 'aes-256-cbc', "$saltWithPassword", null, $iv
	    );
	    $msg_encrypted_bundle = "$iv:$salt:$encrypted";
	    return $msg_encrypted_bundle;
	}

	function decrypt($msg_encrypted_bundle, $password){
		$password = sha1($password);

		$components = explode( ':', $msg_encrypted_bundle );
		$iv            = $components[0];
		$salt          = hash('sha256', $password.$components[1]);
		$encrypted_msg = $components[2];

		$decrypted_msg = openssl_decrypt(
		  $encrypted_msg, 'aes-256-cbc', $salt, null, $iv
		);

		if ( $decrypted_msg === false )
			return false;

		$msg = substr( $decrypted_msg, 41 );
		return $decrypted_msg;
	}

	class usr{}


	$random_salt      = 'hello_1m_@_SaLT';
	$username = $_POST["name_user"];
	$pass = $_POST["password_user"]; //123

	$a = encrypt($pass, $random_salt);
	$password = decrypt($a,$random_salt);

	

	
 	$query =  mysqli_query($conn,"SELECT * FROM users WHERE name_user='$username'");


		if (mysqli_num_rows($query) == 0)
		{
				$response = new usr();
				$response->success = 'not exist';
				$response->message = "Account not exist";
				die(json_encode($response));
		}
		else {

			$row = mysqli_fetch_array($query);
			$passwordHash = $row['password_user'];
			$b = decrypt($passwordHash,$random_salt);
			$active = $row['active'];

					
			//echo var_dump($a);
			//var_dump($b);
			//var_dump($active);

			if($password == $b) {	
				if($active == 1){
					if (!empty($row)){
						//$update = mysqli_query($conn,"UPDATE users SET isLoggedin = 1 where name_user = '$username' ");

						$response = new usr();
						$response->success = 'success';
						$response->message = "Selamat datang ".$row['name_user'];
						$response->id = $row['id_user'];
						$response->username = $row['name_user'];
						$response->fullname = $row['fullname_user'];
						$response->password = $row['password_user'];
						die(json_encode($response));	
					}
				}else {
						$response = new usr();
						$response->success = 'not active';
						$response->message = "Username not active, Please contact administrator.";
						die(json_encode($response));
				}
				
			}
			else{
					$response = new usr();
					$response->success = 'fail';
					$response->message = "Username or Password is wrong";
					die(json_encode($response));
			}

		}

		
	
	mysqli_close($conn);

?>