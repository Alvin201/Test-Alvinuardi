<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once 'connect.php';

$id_user    = $_GET['id_user'];

$query = "SELECT a.*,
                 b.id_category,b.name_category,b.price_category,
                 c.fullname_user 
                 FROM job_order as a 
LEFT JOIN work_category as b ON b.id_category = a.id_work_category 
LEFT JOIN users as c ON c.id_user = a.id_user
WHERE c.id_user = '".$id_user."' AND a.is_active = 0 ORDER BY a.id_job ASC ";

$result = mysqli_query($conn, $query);

$response = array();
$response["status"] = "success";
$response["data"] = array();


while( $row = mysqli_fetch_assoc($result) ){


    array_push($response["data"], 
    array(
        'id_job'        =>$row['id_job'], 
        'id_work_category'      =>$row['id_work_category'],
        
        'data_category' => array(
            'id_category'    =>$row['id_category'],
            'name_category'    =>$row['name_category'],
            'price_category'    =>$row['price_category']
        ),
        
        'data_user' => array(
            'id_user'   =>$row['id_user'],
            'fullname_user'    => $row['fullname_user']
        ),

        'name_customer'     =>$row['name_customer'],
        'alamat'    =>$row['alamat'],
        



        'is_active'    =>$row['is_active']

        )
    );

 

}

echo json_encode($response);

mysqli_close($conn);

?>