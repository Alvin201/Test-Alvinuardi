<?php 
define('host', 'localhost');
define('user', 'root');
define('pass', '');
define('db', 'work_order');

$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
?>