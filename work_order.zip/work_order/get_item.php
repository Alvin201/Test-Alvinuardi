<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once 'connect.php';

$query = "SELECT * FROM master_item as a ORDER BY a.id_item ASC ";
$result = mysqli_query($conn, $query);


$response = array();
$response["status"] = "success";
$response["data"] = array();


while( $row = mysqli_fetch_assoc($result) ){

    $h['id_item'] = $row["id_item"];
    $h['name_item'] = $row["name_item"];
    $h['price_item'] =$row['price_item'];
    array_push($response["data"], $h);

}

echo json_encode($response);

mysqli_close($conn);

?>